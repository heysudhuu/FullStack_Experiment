document.addEventListener('DOMContentLoaded', () => {
    const themeSwitcher = document.getElementById('theme-switcher');
    const body = document.body;

    // Custom Message Box Elements
    const messageBox = document.getElementById('custom-message-box');
    const messageText = document.getElementById('message-text');
    const messageBoxCloseBtn = document.getElementById('message-box-close-btn');

    /**
     * Displays a custom message box.
     * @param {string} message - The message to display.
     */
    function showMessageBox(message) {
        messageText.textContent = message;
        messageBox.classList.add('show');
    }

    // Close button for the custom message box
    messageBoxCloseBtn.addEventListener('click', () => {
        messageBox.classList.remove('show');
    });

    // Close message box if clicked outside (optional, but good UX)
    messageBox.addEventListener('click', (event) => {
        if (event.target === messageBox) {
            messageBox.classList.remove('show');
        }
    });

    // Theme Switcher Logic
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.className = savedTheme;
    } else {
        body.className = 'light-theme'; // Default to light theme
    }

    themeSwitcher.addEventListener('click', () => {
        if (body.classList.contains('light-theme')) {
            body.classList.remove('light-theme');
            body.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark-theme');
        } else {
            body.classList.remove('dark-theme');
            body.classList.add('light-theme');
            localStorage.setItem('theme', 'light-theme');
        }
    });

    // Sidebar navigation active class logic
    const sidebarLinks = document.querySelectorAll('.sidebar-nav a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            // Remove active class from all links
            sidebarLinks.forEach(item => item.classList.remove('active'));
            // Add active class to the clicked link
            this.classList.add('active');
            // Allow default hash behavior to scroll to section
        });
    });

    // --- Student List Search and Filter Functionality ---
    const globalSearchInput = document.getElementById('global-search-input');
    const studentListTableBody = document.querySelector('#student-list-table tbody');
    const studentListRows = studentListTableBody ? Array.from(studentListTableBody.querySelectorAll('tr')) : [];

    const classFilterSelect = document.getElementById('class-filter-select');
    const sectionFilterSelect = document.getElementById('section-filter-select');
    const applyFiltersBtn = document.getElementById('apply-filters-btn');

    /**
     * Applies search and filter criteria to the student list table.
     */
    function applyTableFilters() {
        const searchTerm = globalSearchInput.value.toLowerCase().trim();
        const selectedClass = classFilterSelect.value;
        const selectedSection = sectionFilterSelect.value;

        studentListRows.forEach(row => {
            const name = row.children[0].textContent.toLowerCase();
            const studentClass = row.children[1].textContent.toLowerCase();
            const section = row.children[2].textContent.toLowerCase();
            const uid = row.children[3].textContent.toLowerCase();
            const department = row.children[4].textContent.toLowerCase();

            // Check for search term match across relevant columns
            const matchesSearch = searchTerm === '' ||
                                  name.includes(searchTerm) ||
                                  uid.includes(searchTerm) ||
                                  studentClass.includes(searchTerm) ||
                                  section.includes(searchTerm) ||
                                  department.includes(searchTerm);

            // Check for class filter match
            const matchesClass = selectedClass === 'all' || studentClass === selectedClass;

            // Check for section filter match
            const matchesSection = selectedSection === 'all' || section === selectedSection;

            // Show or hide row based on combined criteria
            if (matchesSearch && matchesClass && matchesSection) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Event listener for global search input
    if (globalSearchInput) {
        globalSearchInput.addEventListener('input', applyTableFilters);
    }

    // Event listener for apply filters button
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', () => {
            applyTableFilters();
            showMessageBox(`Filters applied: Class '${classFilterSelect.value}', Section '${sectionFilterSelect.value}'.`);
        });
    }

    // --- Basic Click Handlers for other conceptual buttons ---

    // Student List - View Profile buttons
    document.querySelectorAll('.view-btn').forEach(button => {
        button.addEventListener('click', () => {
            const studentName = button.closest('tr').children[0].textContent;
            console.log(`[View Profile Button Clicked] Attempting to view profile for: ${studentName}`);
            showMessageBox(`Conceptual: Loading detailed profile for ${studentName}. In a real app, this would show more data.`);
        });
    });

    // Mark Attendance - Load Students for Marking button
    const loadStudentsBtn = document.getElementById('load-students-btn');
    if (loadStudentsBtn) {
        loadStudentsBtn.addEventListener('click', () => {
            const classSection = document.getElementById('class-section-select').value;
            const attendanceDate = document.getElementById('attendance-date-input').value;
            if (classSection === "") {
                showMessageBox("Please select a Class/Section to load students.");
                return;
            }
            console.log(`[Load Students Button Clicked] Class/Section: ${classSection}, Date: ${attendanceDate}`);
            showMessageBox(`Conceptual: Loading students for attendance marking for ${classSection} on ${attendanceDate}.`);
            // In a real app: Fetch student list for selected class/date from backend
        });
    }

    // Leave Management - Approve/Reject buttons
    document.querySelectorAll('.approve-btn').forEach(button => {
        button.addEventListener('click', () => {
            const studentName = button.closest('tr').children[0].textContent;
            console.log(`[Approve Button Clicked] Approving leave for: ${studentName}`);
            showMessageBox(`Conceptual: Approving leave for ${studentName}. This would update the status in a real system.`);
        });
    });

    document.querySelectorAll('.reject-btn').forEach(button => {
        button.addEventListener('click', () => {
            const studentName = button.closest('tr').children[0].textContent;
            console.log(`[Reject Button Clicked] Rejecting leave for: ${studentName}`);
            showMessageBox(`Conceptual: Rejecting leave for ${studentName}. This would update the status in a real system.`);
        });
    });

    // Reports & Analytics - Generate Report button
    const generateReportBtn = document.getElementById('generate-report-btn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', () => {
            const reportType = document.getElementById('report-type-select').value;
            if (reportType === "") {
                showMessageBox("Please select a Report Type to generate.");
                return;
            }
            console.log(`[Generate Report Button Clicked] Report Type: ${reportType}`);
            showMessageBox(`Conceptual: Generating a '${reportType}' report. This would produce a report or update charts.`);
            // In a real app: Trigger report generation (e.g., PDF, CSV) or data visualization update
        });
    }

    // System Settings - Configure Notifications button
    const configureNotificationsBtn = document.getElementById('configure-notifications-btn');
    if (configureNotificationsBtn) {
        configureNotificationsBtn.addEventListener('click', () => {
            console.log('[Configure Notifications Button Clicked]');
            showMessageBox('Conceptual: Opening notification configuration settings. This would lead to a detailed setup page.');
            // In a real app: Navigate to a settings page or open a configuration modal
        });
    }

    // System Settings - Integrate Systems button
    const integrateSystemsBtn = document.getElementById('integrate-systems-btn');
    if (integrateSystemsBtn) {
        integrateSystemsBtn.addEventListener('click', () => {
            console.log('[Integrate Systems Button Clicked]');
            showMessageBox('Conceptual: Initiating external system integration workflow. This would guide you through connecting with SIS/LMS/ERP.');
            // In a real app: Navigate to an integration setup page
        });
    }

    // System Settings - Manage Roles button
    const manageRolesBtn = document.getElementById('manage-roles-btn');
    if (manageRolesBtn) {
        manageRolesBtn.addEventListener('click', () => {
            console.log('[Manage Roles Button Clicked]');
            showMessageBox('Conceptual: Opening user role management interface. Here you could define permissions for Admin, Teacher, Student, Parent.');
            // In a real app: Navigate to user management section
        });
    }

    // System Settings - Enable Offline Mode button
    const enableOfflineBtn = document.getElementById('enable-offline-btn');
    if (enableOfflineBtn) {
        enableOfflineBtn.addEventListener('click', () => {
            console.log('[Enable Offline Mode Button Clicked]');
            showMessageBox('Conceptual: Toggling offline data sync capabilities. This would involve service workers and local data storage.');
            // In a real app: Trigger service worker registration/offline data setup
        });
    }
});
