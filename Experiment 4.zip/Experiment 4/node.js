const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let employees = [];

let nextId = 1;

function showMenu() {
  console.log('\n=====(sudhanshu yadav) Employee Management System(23bcs14344) =====');
  console.log('1. Add a new employee');
  console.log('2. View all employees');
  console.log('3. Update an employee');
  console.log('4. Delete an employee');
  console.log('5. Exit');
  console.log('======================================');

  rl.question('Please enter your choice (1-5): ', (choice) => {
    switch (choice.trim()) {
      case '1':
        addEmployee();
        break;
      case '2':
        viewEmployees();
        break;
      case '3':
        updateEmployee();
        break;
      case '4':
        deleteEmployee();
        break;
      case '5':
        console.log('Exiting the application. Goodbye!');
        rl.close();
        break;
      default:
        console.log('Invalid choice. Please enter a number from 1 to 5.');
        showMenu();
        break;
    }
  });
}

function addEmployee() {
  console.log('\n--- Add a New Employee ---');
  rl.question('Enter employee name: ', (name) => {
    rl.question('Enter employee department: ', (department) => {
      const newEmployee = {
        id: nextId++,
        name: name,
        department: department
      };
      employees.push(newEmployee);
      console.log(`\nEmployee '${name}' added successfully!`);
      showMenu();
    });
  });
}

function viewEmployees() {
  console.log('\n--- All Employees ---');
  if (employees.length === 0) {
    console.log('No employees found.');
  } else {
    employees.forEach(employee => {
      console.log(`ID: ${employee.id}, Name: ${employee.name}, Department: ${employee.department}`);
    });
  }
  showMenu();
}

function updateEmployee() {
  console.log('\n--- Update an Employee ---');
  rl.question('Enter the ID of the employee to update: ', (id) => {
    const employeeId = parseInt(id, 10);
    const employeeToUpdate = employees.find(emp => emp.id === employeeId);

    if (employeeToUpdate) {
      rl.question(`Enter new name (current: ${employeeToUpdate.name}): `, (newName) => {
        rl.question(`Enter new department (current: ${employeeToUpdate.department}): `, (newDepartment) => {
          employeeToUpdate.name = newName || employeeToUpdate.name;
          employeeToUpdate.department = newDepartment || employeeToUpdate.department;
          console.log(`\nEmployee ID ${employeeId} updated successfully!`);
          showMenu();
        });
      });
    } else {
      console.log('Employee with that ID not found.');
      showMenu();
    }
  });
}

function deleteEmployee() {
  console.log('\n--- Delete an Employee ---');
  rl.question('Enter the ID of the employee to delete: ', (id) => {
    const employeeId = parseInt(id, 10);
    const employeeIndex = employees.findIndex(emp => emp.id === employeeId);

    if (employeeIndex !== -1) {
      const deletedEmployee = employees.splice(employeeIndex, 1);
      console.log(`\nEmployee '${deletedEmployee[0].name}' (ID: ${employeeId}) deleted successfully.`);
    } else {
      console.log('Employee with that ID not found.');
    }
    showMenu();
  });
}

showMenu();